const Footer = {
  render() {
    return `
    <footer>
        <div class="footer__img">
          <img src="logo.png" alt="airsoft__logo"/>
        </div>
    </footer>
`
  },
}

export default Footer
